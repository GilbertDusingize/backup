import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import profile from './assets/profile.jpeg'; // Import it first

function App() {
 return (
    <div className="homepage">
      {/* Navigation Bar */}
      <nav className="navbar">
        <div className="logo">Kabutare TSS</div>
        <ul className="nav-links">
          <li>Home</li>
          <li>Departments</li>
          <li>Admissions</li>
          <li>Contact</li>
        </ul>
      </nav>

      {/* Hero Section */}
      <header className="hero">
        <h1>Nurturing Nature, Securing the Future</h1>
        <p>Leading the way in Agricultural Excellence and Technical Innovation.</p>
        <button className="cta-btn">View Programs</button>
      </header>

      {/* NEW: The 4 Trades Section */}
      <section className="trades-section">
        <h2 className="section-title">Our Specialized Trades</h2>
        <div className="trades-grid">
          
          <div className="trade-card">
            <div className="icon">🌱</div>
            <h3>Agriculture</h3>
            <p>Mastering modern farming techniques, crop management, and sustainable soil health.</p>
          </div>

          <div className="trade-card">
            <div className="icon">🐄</div>
            <h3>Animal Health</h3>
            <p>Focusing on veterinary basics, livestock nutrition, and ethical animal husbandry.</p>
          </div>

          <div className="trade-card">
            <div className="icon">🥫</div>
            <h3>Food Processing</h3>
            <p>Learning the science of preservation, packaging, and quality control of food products.</p>
          </div>

          <div className="trade-card">
            <div className="icon">🌲</div>
            <h3>Forestry</h3>
            <p>Dedicated to forest conservation, timber management, and ecosystem restoration.</p>
          </div>

        </div>
      </section>

      {/* Principal's Message */}
      <section className="principal-section">
        <div className="principal-content">
          <div className="principal-image">
            <img src={profile} alt="Principal" />
          </div>
          <div className="principal-text">
            <h2>Principal's Message</h2>
            <p>"Our institute is proud to train the next generation of specialists in the vital fields of agriculture and natural resources."</p>
            <strong>— Dr. Sarah Jenkins</strong>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>&copy; 2025 Agro-Tech Institute. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App
