import react from "react";
import logo from "./assets/school-logo.jpg";
function SchoolLogo() {
  return (
    <div className="school-logo">
      <img src={logo} alt="School Logo" className="logo1" />
    </div>
  );
}
export default SchoolLogo;