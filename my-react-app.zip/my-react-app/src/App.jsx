import React from 'react';
import './App.css';
import Header from "./Header.jsx";
import Heading from "./Heading.jsx";
import TradeCard from './TradeCard.jsx';
import trades from "./Trades.js";
import Note from "./Note.jsx";
import Footer from "./Footer.jsx";

// Helper function to render each card
function createTradeCard(trade) {
  return (
    <TradeCard
      key={trade.id}
      emoji={trade.emoji} // Ensure your Trades.js has emojis!
      name={trade.name}
      title={trade.title}
      description={trade.description}
    />
  );
}

function App() {
  return (
    <div className="app-container">
      <Header />

      <main>
        {/* Section 1: Hero/Introduction */}
        <section id="hero">
          <Heading />
        </section>

        {/* Section 2: The Main Gallery of Trades */}
        <section id="trades-list">
          <h2 className="section-title">Explore Our Trades</h2>
          <dl className="dictionary">
            {trades.map(createTradeCard)}
          </dl>
        </section>

        {/* Section 3: Additional Resources or Notes */}
        <section id="extra-notes">
          <h2 className="section-title">Important Information</h2>
          <div className="notes-container">
             <Note />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default App;
