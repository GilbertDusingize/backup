const trades = [
  { id: 1, name: 'Agriculture',title: 'Sustainable Agriculture',description:'Learn modern farming techniques that improve crop production, soil health, and food security using environmentally friendly practices.'

   },
  { id: 2, name: 'Veterinary',title: 'Animal Health',description:'Gain skills in animal health care, disease prevention, and livestock management to support healthy animals and safe food production'

   },
  { id: 3, name: 'Food Processing',title: 'Food Processing Technology',description:'Explore the science and technology behind food processing, preservation, and packaging to ensure food safety and quality from farm to table.'

  },
  { id: 4, name: 'Forestry' ,title: 'Forest Conservation',description:'Study forest conservation, tree management, and sustainable use of forest resources to protect the environment and biodiversity.'

  }
];

export default trades;