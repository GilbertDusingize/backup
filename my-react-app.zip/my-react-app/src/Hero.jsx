import React, { useState, useEffect } from "react";

const images = [
  "https://via.placeholder.com/1200x400?text=Slide+1",
  "https://via.placeholder.com/1200x400?text=Slide+2",
  "https://via.placeholder.com/1200x400?text=Slide+3"
];

function Hero() {
  const [index, setIndex] = useState(0);

  // Automatic sliding effect
  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000); // Changes every 5 seconds
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="hero">
      <div className="carousel">
        <img src={images[index]} alt="Hero Slide" className="hero-image" />
        <div className="hero-text">
          <h1>Welcome to Keeper</h1>
          <p>Organize your thoughts, one note at a time.</p>
        </div>
      </div>
    </section>
  );
}

export default Hero;